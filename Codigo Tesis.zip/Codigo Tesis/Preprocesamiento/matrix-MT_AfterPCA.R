# Leer los datos del archivo CSV "matrizAfterBatchRPKMFiltrado.csv" 
# y almacenarlos en el objeto 'datcomp'
datcomp <- read.csv("matrixAfterBatchRPKMFiltrado.csv",header = TRUE, row.names = 1)

# Transponer los datos para tener muestras en filas y genes en columnas
datcomp <- t(datcomp)

# Cargar la librería 'rrcov'
library(rrcov)

# Realizar PCA con el método de Hubert
pcaHub <- PcaHubert(datcomp);pcaHub$flag

# Identificar los outliers
outliers <- which(pcaHub@flag=='FALSE') 

# Filtrar los datos originales utilizando la información de los outliers
datExpr=datcomp[pcaHub$flag, ]

# Transponer la matriz filtrada para tener genes en filas y muestras en columnas
datExpr <- t(datExpr)

# Escribir los datos filtrados 
write.csv(datExpr, "matrix-MT_AfterPCA.csv", row.names = TRUE)
