# Cargamos los datos desde el archivo
data <- read.table("GRENADINE-Bayesian_Ridge-MT.txt", header = TRUE)

# Ordenamos los datos por la columna de valor de interacción de manera descendente
data_sorted <- data[order(-data$Valor), ]

# Tomamos las primeras 100447 interacciones
data_top <- data_sorted[1:100447, ]

# Escribimos los resultados en un nuevo archivo de texto
write.table(data_top, file = "FINAL-Bayesian_Ridge-MT_10.txt", sep = "\t", row.names = FALSE, quote = FALSE, col.names = TRUE)
