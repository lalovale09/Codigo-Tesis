# Cargar las librerías
library(readxl)
library(openxlsx)

# Leer el archivo Excel
datos <- read_excel("Data.xlsx")

# Utilizar la función sub() para modificar los identificadores
datos$Protein_name <- sub("\\.\\d+.*", "", datos$Protein_name)

# Guardar los datos modificados en un nuevo archivo Excel
# Puedes cambiar el nombre y la ruta del archivo según tu preferencia
write.xlsx(datos, "Reanotacion.xlsx", row.names = FALSE)
