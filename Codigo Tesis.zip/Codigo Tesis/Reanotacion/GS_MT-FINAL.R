# Leer el archivo de texto
data <- read.table("TransReNetMtub2011.txt", sep = "\t", stringsAsFactors = FALSE)

# Seleccionar la segunda columna
interacciones <- data[, 2]

# Dividir los elementos de la segunda columna en dos columnas
interacciones_2 <- do.call(rbind, strsplit(interacciones, " "))

# Guardar el resultado en un archivo CSV
write.csv(interacciones_2, "GS_MT.csv", row.names = FALSE)

# Cargar el paquete necesario
library(dplyr)

# Leer el archivo CSV
datos <- read.csv("GS_MT.csv", header = FALSE)

# Obtener la lista de interacciones verdaderas
interacciones_verdaderas <- filter(datos, V3 == 1) %>%
  select(V1, V2)

# Obtener la lista completa de TF y TG únicos
tf_unique <- unique(datos$V1)
tg_unique <- unique(datos$V2)

# Crear todas las posibles combinaciones de TF y TG
todas_combinaciones <- expand.grid(TF = tf_unique, TG = tg_unique)

# Verificar si cada combinación está en las interacciones verdaderas
todas_combinaciones$EsVerdadero <- mapply(function(tf, tg) {
  any(interacciones_verdaderas$V1 == tf & interacciones_verdaderas$V2 == tg)
}, todas_combinaciones$TF, todas_combinaciones$TG)

# Mostrar la tabla de resultados con 0 para interacciones falsas
resultado_final <- data.frame(
  TF = todas_combinaciones$TF,
  TG = todas_combinaciones$TG,
  Unos = ifelse(todas_combinaciones$EsVerdadero, 1, 0)
)

#Escribir el resultado final
write.csv(resultado_final, "GS_MT-FINAL.csv", row.names = FALSE)
