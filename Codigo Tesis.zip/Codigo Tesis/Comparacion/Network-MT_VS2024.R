# Cargar el primer archivo
archivo1 <- read.table("TransReNetMtub2011.txt", header = FALSE) # Asegúrate de ajustar el nombre del archivo

# Seleccionar las interacciones de Golden Standard
archivo1 <- archivo1[, c(3, 4)]

# Renombrar las columnas del primer archivo como "Source" y "Target"
colnames(archivo1)[1] <- "Source"
colnames(archivo1)[2] <- "Target"

# Cargar el segundo archivo
archivo2 <- read.table("Network_MT_AGBT-GS_ABGT_10.txt", header = TRUE) # Ajusta el nombre del archivo si es necesario

# Renombrar las columnas del segundo archivo como "Source" y "Target"
colnames(archivo2)[1] <- "Source"
colnames(archivo2)[2] <- "Target"

# Combinar los datos de ambos archivos en uno solo
datos_combinados <- rbind(archivo1, archivo2)

# Escribimos los resultados en un nuevo archivo de texto
write.table(datos_combinados, file = "Network-MT_VS2024.txt", sep = "\t", quote = FALSE, row.names = FALSE, col.names = TRUE)
