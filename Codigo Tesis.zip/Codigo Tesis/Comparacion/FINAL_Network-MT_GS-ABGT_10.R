# Cargar los datos de los 2 archivos
data1 <- read.table("FINAL_Network-MT_ABGT_10.txt", header = TRUE, stringsAsFactors = FALSE)
data2 <- read.table("TransReNetMtub2011.txt", header = FALSE, stringsAsFactors = FALSE)

# Seleccionar las interacciones de Golden Standard
data3 <- data2[, c(3, 4)]

# Crear conjuntos de interacciones para cada archivo
set1 <- paste(data1$Factor, data1$Gen, sep = "-")
set2 <- paste(data3$V3, data3$V4, sep = "-")

# Encontrar las interacciones compartidas
common_interactions <- Reduce(intersect, list(set1, set2))

# Separar las interacciones en factores y genes
common_interactions_split <- strsplit(common_interactions, "-")
common_interactions_df <- data.frame(Factor = sapply(common_interactions_split, `[`, 1), Gen = sapply(common_interactions_split, `[`, 2))

# Escribimos los resultados en un nuevo archivo de texto
write.table(common_interactions_df, file = "FINAL_Network-MT_GS-ABGT_10.txt", sep = "\t", quote = FALSE, row.names = FALSE, col.names = TRUE)
