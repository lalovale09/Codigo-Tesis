# Cargar el primer archivo
archivo1 <- read.table("FINAL_Network-MT_ABGT_10.txt", header = TRUE) # Asegúrate de ajustar el nombre del archivo

# Cargar el segundo archivo
archivo2 <- read.table("FINAL_Network-MT_GS-ABGT_10.txt", header = TRUE) # Ajusta el nombre del archivo si es necesario

# Identificar las interacciones en común
interacciones_comunes <- intersect(paste(archivo1$Factor, archivo1$Gen, sep = "-"), 
                                   paste(archivo2$Factor, archivo2$Gen, sep = "-"))

# Filtrar las interacciones que no son comunes
interacciones_filtradas <- archivo1[!(paste(archivo1$Factor, archivo1$Gen, sep = "-") %in% interacciones_comunes), ]

# Escribimos los resultados en un nuevo archivo de texto
write.table(interacciones_filtradas, file = "Network_MT_AGBT-GS_ABGT_10.txt", sep = "\t", quote = FALSE, row.names = FALSE, col.names = TRUE)
