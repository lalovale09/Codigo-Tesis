# Cargar los datos de los 4 archivos
data1 <- read.table("FINAL-AdaBoost-MT_10.txt", header = TRUE, stringsAsFactors = FALSE)
data2 <- read.table("FINAL-Bayesian_Ridge-MT_10.txt", header = TRUE, stringsAsFactors = FALSE)
data3 <- read.table("FINAL-GENIE3-MT_10.txt", header = TRUE, stringsAsFactors = FALSE)
data4 <- read.table("FINAL-TIGRESS-MT_10.txt", header = TRUE, stringsAsFactors = FALSE)

# Crear conjuntos de interacciones para cada archivo
set1 <- paste(data1$Factor, data1$Gen, sep = "-")
set2 <- paste(data2$Factor, data2$Gen, sep = "-")
set3 <- paste(data3$Factor, data3$Gen, sep = "-")
set4 <- paste(data4$Factor, data4$Gen, sep = "-")

# Encontrar las interacciones compartidas
common_interactions <- Reduce(intersect, list(set1, set2, set3, set4))

# Separar las interacciones en factores y genes
common_interactions_split <- strsplit(common_interactions, "-")

# Separar las interacciones en factores y genes
common_interactions_df <- data.frame(Factor = sapply(common_interactions_split, `[`, 1), Gen = sapply(common_interactions_split, `[`, 2))

# Escribimos los resultados en un nuevo archivo de texto
write.table(common_interactions_df, file = "FINAL_Network-MT_ABGT_10.txt", sep = "\t", quote = FALSE, row.names = FALSE, col.names = TRUE)
