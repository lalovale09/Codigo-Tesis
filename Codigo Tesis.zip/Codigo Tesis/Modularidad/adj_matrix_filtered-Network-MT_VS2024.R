# Cargar el archivo de entrada
GS <- read.table("Network-MT_VS2024.txt", header = TRUE)

# Filtrar y mantener solo la primera columna y nodos únicos
unique_nodes <- unique(GS$Source)

# Filtrar el dataframe original para incluir solo las interacciones que tienen nodos únicos en la primera columna
filtered_GS <- GS[GS$Source %in% unique_nodes & GS$Target %in% unique_nodes, ]

#write.table(filtered_GS, file = "Network-MT_VS2023_Filtered-reannotated.txt", sep = "\t", quote = FALSE, row.names = FALSE, col.names = TRUE)

# Crear una matriz de adyacencia vacía
matriz_adyacencia <- matrix(0, nrow = length(unique_nodes), ncol = length(unique_nodes), dimnames = list(unique_nodes, unique_nodes))

# Llenar la matriz de adyacencia con las interacciones correspondientes
for (i in 1:nrow(filtered_GS)) {
  source <- filtered_GS$Source[i]
  target <- filtered_GS$Target[i]
  matriz_adyacencia[source, target] <- 1  # Puedes modificar el valor según la interacción
}

# Guardar la matriz de adyacencia en un archivo
write.table(matriz_adyacencia, "adj_matrix_filtered-Network-MT_VS2024.txt", sep = "\t", quote = FALSE, row.names = TRUE, col.names = TRUE)
