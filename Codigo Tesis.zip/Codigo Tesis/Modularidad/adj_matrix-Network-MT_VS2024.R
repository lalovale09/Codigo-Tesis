#Red completa

# Cargar el archivo de entrada
GS <- read.table("Network-MT_VS2024.txt", header = TRUE)

# Agregar una columna adicional para representar la intersección entre nodos
gs2 <- cbind(GS, 1)
colnames(gs2)[3]  <- "Intersection"

# Cargar la librería readr para trabajar con datos tabulares
library(readr)

# Obtener la lista de nodos únicos en la red
nodos <- unique(c(gs2$Source, gs2$Target))

# Crear una matriz de adyacencia vacía
matriz_adyacencia <- matrix(0, nrow = length(nodos), ncol = length(nodos), dimnames = list(nodos, nodos))

# Llenar la matriz de adyacencia con las interacciones correspondientes
for (i in 1:nrow(gs2)){
  source <- gs2$Source[i]
  target <- gs2$Target[i]
  intersection <- gs2$Intersection[i]
  
  matriz_adyacencia[source, target] <- intersection
}

# Guardar la matriz de adyacencia en un archivo
write.table(matriz_adyacencia, "adj_matrix-Network-MT_VS2024.txt", sep = "\t", quote = FALSE, row.names = TRUE, col.names = TRUE)
