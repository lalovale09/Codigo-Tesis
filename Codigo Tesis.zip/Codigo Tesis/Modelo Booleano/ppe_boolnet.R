# Cargar las librerías
library("BoolNet")
library("igraph")
library("ggplot2")

# Cargar el archivo con las funciones booleanas
cellcycle <- loadNetwork("ppe1.txt")

# Guardar el gráfico como PNG con una resolución de 300 DPI
png("grafo1.png", width = 2200, height = 2000, res = 300)
# Visualizar la estructura de la red
plotNetworkWiring(cellcycle, layout = layout.auto, edge.size=8, edge.arrow.size = 0.5, 
                  vertex.size = 12, vertex.label.font = 0.2)
dev.off()  # Esto cierra el dispositivo gráfico PNG

# Obtener los atractores de la red
sink("salida.txt", append = TRUE)
attr <- getAttractors(cellcycle)
attr
sink()

# Guardar el gráfico como PNG con una resolución de 300 DPI
#png("mi_grafo2.png", width = 2200, height = 2000, res = 300)
# Crear un nuevo gráfico para mostrar los atractores
#plotAttractors(attr, modo = c("table"))
#dev.off()  # Esto cierra el dispositivo gráfico PNG

# Guardar el gráfico como PNG con una resolución de 300 DPI
png("grafo2.png", width = 2200, height = 2000, res = 300)
# Crear un gráfico para mostrar la estructura de los estados y las transiciones entre ellos
plotStateGraph(attr, drawLegend = FALSE,piecewise = TRUE, layout = layout.auto)
dev.off()  # Esto cierra el dispositivo gráfico PNG

testNetworkProperties(cellcycle,
                      numRandomNets=100,
                      testFunction="testIndegree")

testNetworkProperties(cellcycle,
                      numRandomNets=100,
                      testFunction="testIndegree",
                      accumulation="kullback_leibler")

# Generar una red de regulación booleana aleatoria con 7 nodos
netrandom = loadNetwork("cellcycle.txt")
#net <- generateRandomNKNetwork(n=19, k=2,
#                               topology="homogeneous",
#                               linkage="lattice",
#                               zeroBias=0.5)

# Guardar el gráfico como PNG con una resolución de 300 DPI
png("grafo3.png", width = 2200, height = 2000, res = 300)
# Visualizar la estructura de la red
plotNetworkWiring(netrandom)
dev.off()  # Esto cierra el dispositivo gráfico PNG

# Guardar el gráfico como PNG con una resolución de 300 DPI
#png("mi_grafo4.png", width = 2200, height = 2000, res = 300)
# Visualizar la estructura de la red aleatoria
#plotNetworkWiring(net, edge.size=5, edge.arrow.size = 0.25, vertex.size = 14, 
#                  vertex.label.font = 0.2)

# save it to a file
#saveNetwork(net, file="cellcycle.txt", generateDNFs = TRUE)
#dev.off()  # Esto cierra el dispositivo gráfico PNG

# Obtener los atractores de la red aleatoria
sink("salidaRandom.txt", append = TRUE)
attr1 <- getAttractors(netrandom)
attr1
sink()

# Guardar el gráfico como PNG con una resolución de 300 DPI
#png("grafo4.png", width = 2200, height = 2000, res = 300)
# Mostrar los atractores de la red aleatoria
#plotAttractors(attr1)
#dev.off()  # Esto cierra el dispositivo gráfico PNG

# Guardar el gráfico como PNG con una resolución de 300 DPI
png("grafo4.png", width = 2200, height = 2000, res = 300)
# Crear un gráfico para mostrar la estructura de los estados y las transiciones entre ellos
plotStateGraph(attr1, piecewise = TRUE, layout = layout.auto)
dev.off()  # Esto cierra el dispositivo gráfico PNG
