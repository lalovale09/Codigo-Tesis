# Leer el archivo de texto
datos <- readLines("salida.txt")

# Inicializar vectores para almacenar los datos
attractors <- character()
basins <- numeric()

# Recorrer cada línea del texto para extraer la información
for (linea in datos) {
  if (grepl("Attractor \\d+ is a simple attractor consisting of \\d+ state\\(s\\) and has a basin of \\d+ state\\(s\\):", linea)) {
    # Extraer el número de la cuenca del atractor
    basin <- as.numeric(gsub(".*has a basin of (\\d+) state\\(s\\):", "\\1", linea))
    
    # Añadir el atractor y la cuenca a los vectores
    attractors <- c(attractors, gsub(".*Attractor (\\d+) is.*", "Attractor \\1", linea))
    basins <- c(basins, basin)
  }
}

# Crear el data frame con los resultados
resultados <- data.frame(Attractor = attractors, Basin_of_State = basins)

# Exportar la tabla a un archivo CSV
write.csv(resultados, "resultados_attractors.csv", row.names = FALSE)
