# Instala el paquete openxlsx si no lo tienes instalado
# install.packages("openxlsx")

# Carga el paquete openxlsx
library(openxlsx)

# Lee el archivo xlsx
datos_excel <- read_excel("Network-MT_VS2024-Communuties.xlsx", col_names = TRUE)

# Define la lista de genes a buscar
genes_buscar <- c(
  "Rv2359", "Rv0757", "Rv0650", "Rv3862c", "Rv1719",
  "Rv2370c", "Rv0414c", "Rv0158", "Rv3855", "Rv0047c",
  "Rv0602c", "Rv1453", "Rv1219c", "Rv1049", "Rv1186c",
  "Rv2989", "Rv1129c", "Rv2166c", "Rv0022c", "Rv0581",
  "Rv1994c", "Rv0260c"
)

# Filtra las filas donde Source y Target contengan los genes buscados
datos_filtrados <- datos_excel[datos_excel$Source %in% genes_buscar & datos_excel$Target %in% genes_buscar, ]

source <- unique(datos_filtrados$Source)

# Si deseas guardar los datos en un nuevo archivo CSV
write.csv(datos_filtrados, "Interactions-Communities-GRN(1).csv", row.names = FALSE)
