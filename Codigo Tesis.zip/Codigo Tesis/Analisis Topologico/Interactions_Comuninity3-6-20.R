# Instala el paquete openxlsx si no lo tienes instalado
# install.packages("openxlsx")

# Carga el paquete openxlsx
library(readxl)

# Carga el archivo xlsx
datos <- read_excel("Network-MT_VS2024-Communuties.xlsx", col_names = TRUE)

# Define las comunidades que quieres conservar
comunidades <- c(3, 6, 20)  # Comunidades que deseas conservar en Com1 y Com2

# Filtra las filas donde Com1 y Com2 contengan las comunidades deseadas
datos_filtrados <- datos[datos$Com1 %in% comunidades & datos$Com2 %in% comunidades, ]

source <- unique(datos$Source)
target <- unique(datos$Target)

# Si deseas guardar los datos en un nuevo archivo CSV
write.csv(datos_filtrados, "Interactions_Comuninity3-6-20.csv", row.names = FALSE)
