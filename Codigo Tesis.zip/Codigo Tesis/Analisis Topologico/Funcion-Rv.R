# Cargar las librerías
library(readxl)
library(openxlsx)

# Leer el archivo Excel
datos <- read_excel("Data.xlsx")

# Crear un nuevo vector para almacenar los resultados
datos$protein_names <- sub(".*\\.5 (.*)", "\\1", datos$Protein_name)

datos <- datos[, -c(2)]

# Guardar los datos modificados en un nuevo archivo Excel
# Puedes cambiar el nombre y la ruta del archivo según tu preferencia
write.xlsx(datos, "Funcion-Rv.xlsx", row.names = FALSE)
