# Cargar el archivo CSV como un data frame
matriz <- read.csv("GRENADINE-Bayesian_Ridge-MT.csv", sep = "\t", row.names = 1, header = TRUE)

# Obtener las dimensiones de la matriz
num_filas <- nrow(matriz)
num_columnas <- ncol(matriz)

# Crear una lista para almacenar los datos
lista <- data.frame(
  Factor = character(num_filas * (num_columnas)),
  Gen = character(num_filas * (num_columnas)),
  Valor = numeric(num_filas * (num_columnas))
)

# Llenar la lista con los datos de la matriz de incidencia
contador <- 1
for (i in 1:num_filas) {
  for (j in 1:num_columnas) {
    lista$Factor[contador] <- colnames(matriz)[j]
    lista$Gen[contador] <- rownames(matriz)[i]
    lista$Valor[contador] <- matriz[i, j]
    contador <- contador + 1
  }
}

# Guardar la lista en un archivo de texto
write.table(lista, "GRENADINE-Bayesian_Ridge-MT.txt", sep = "\t", row.names = FALSE, quote = FALSE, col.names = TRUE)
